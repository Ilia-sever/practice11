function f1 () {
	
$("#but").click(function() {
	$("#i1").hide();
	$("#i2").hide();
	$("video").show();
  	$("#d1").css("background", "black");
}
)

 let tr=0;
 $(document).scroll(function () {
    if($(window).scrollTop()+window.outerHeight>=$("#end").offset().top)
    { 
    	if (tr==0) 
    	{
    		$( "#i1" ).animate(
    		{
		    	opacity: 1,
		    	left: "+=10px",
		    }, 1500, function() 
		    {
			  	$( "#i2" ).animate(
			  	{
			  		opacity: 1,
		    		top: "-=7px",
		    	},1500);
			});
    	} 
    	tr=1;} 
});

}